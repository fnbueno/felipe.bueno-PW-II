const mongoose = require('mongoose')

const userSchema = new mongoose.Schema({
  nome: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  idade: {
    type: Number,
    required: true,
  },
}, {
  timestamps: true, // adiciona createdAt e updatedAt automaticamente
})

const User = mongoose.model('User', userSchema)

module.exports = User
