const User = require('./models/User')
require('dotenv').config()
const express = require('express')
const mongoose = require('mongoose')

const app = express()

app.use(express.urlencoded({ extended: true }))
app.use(express.json())


mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('Conectado ao MongoDB!'))
  .catch((err) => console.error('Erro ao conectar:', err))

app.get('/', (req, res) => {
  res.json({ message: 'Oi Express' })
})


app.post('/users', async (req, res) => {
  const { nome, email, idade } = req.body

  try {
    const novoUsuario = await User.create({ nome, email, idade })
    res.status(201).json(novoUsuario)
  } catch (error) {
    res.status(500).json({ message: 'Erro ao criar usuário', error: error.message })
  }
})

app.get('/users', async (req, res) => {
  try {
    const usuarios = await User.find()
    res.status(200).json(usuarios)
  } catch (error) {
    res.status(500).json({ message: 'Erro ao buscar usuários', error: error.message })
  }
})

app.get('/users/:id', async (req, res) => {
  try {
    const usuario = await User.findById(req.params.id)

    if (!usuario) {
      return res.status(404).json({ message: 'Usuário não encontrado' })
    }

    res.status(200).json(usuario)
  } catch (error) {
    res.status(500).json({ message: 'Erro ao buscar usuário', error: error.message })
  }
})

app.put('/users/:id', async (req, res) => {
  const { nome, email, idade } = req.body

  try {
    const usuarioAtualizado = await User.findByIdAndUpdate(
      req.params.id,
      { nome, email, idade },
      { new: true, runValidators: true }
    )

    if (!usuarioAtualizado) {
      return res.status(404).json({ message: 'Usuário não encontrado' })
    }

    res.status(200).json(usuarioAtualizado)
  } catch (error) {
    res.status(500).json({ message: 'Erro ao atualizar usuário', error: error.message })
  }
})

app.delete('/users/:id', async (req, res) => {
  try {
    const usuarioDeletado = await User.findByIdAndDelete(req.params.id)

    if (!usuarioDeletado) {
      return res.status(404).json({ message: 'Usuário não encontrado' })
    }

    res.status(200).json({ message: 'Usuário deletado com sucesso' })
  } catch (error) {
    res.status(500).json({ message: 'Erro ao deletar usuário', error: error.message })
  }
})

app.listen(3000, () => console.log('Servidor rodando na porta 3000'))